#include <stdio.h>

int main() {
  printf("i am a native module");
}
