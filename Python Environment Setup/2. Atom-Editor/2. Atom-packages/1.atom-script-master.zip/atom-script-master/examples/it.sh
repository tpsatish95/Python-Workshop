echo "Not all envs are created equal"
env
