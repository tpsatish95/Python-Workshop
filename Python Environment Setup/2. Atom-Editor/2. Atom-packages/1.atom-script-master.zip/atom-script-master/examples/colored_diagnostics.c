main(){"Warnings/Errors fire on this C code."}
